package com.dao;

import java.util.List;

import com.model.User;

public interface UserDAO {
	 
	public void incluir(User user);

	public List<User> listar();

	public void atualizar(User user);

	public void excluir(User user);
}
