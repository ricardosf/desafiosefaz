package com.dao;

public class UserDAOImpl {
	
	public void incluir(User user) {
		
		if (user == null) {
			throw new PersistenceException("Informe usuario para salvar!");
		}
		
		try {
			
			
		} catch (Exception e) {
			System.out.println("Não foi possivel inserir o usuario. Erro: " + e.getMessage());
		} finally {
			try {
				
				
			} catch (Throwable e2) {
				System.out.println("Erro ao fechar operação de inserção. Mensagem: " + e2.getMessage());
			}
		}
	}
	
	public void atualizar(User user) {

		try {


		} catch (Exception e) {
			System.out.println("Não foi possivel alterar o usuario. Erro: " + e.getMessage());
		} finally {
			try {
				
				
			} catch (Throwable e2) {
				System.out.println("Erro ao fechar operação de atualizacao. Mensagem: " + e2.getMessage());
			}
		}
	}

	public void excluir(User user) {

		try {
			
			
		} catch (Exception e) {
			System.out.println("Não foi possivel excluir o usuario. Erro: " + e.getMessage());
		} finally {
			try {


				
			} catch (Throwable e2) {
				System.out.println("Erro ao fechar operação de excluir. Mensagem: " + e2.getMessage());
			}
		}
	}
	
	public List<User> listar() {

		List<User> users = null;
		try {


			
		} catch (Throwable e) {


		} finally {
			try {


			} catch (Throwable e) {
				System.out.println("Erro ao fechar operação de consulta. Mensagem: " + e.getMessage());
			}
		}
		return users;
	}
	
}
