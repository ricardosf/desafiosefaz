package com.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectDatabase {

	//Conexao com o banco desafiosefaz
	public static void main(String[] args) {
	      Connection con = null;
	      
	      try {
	         Class.forName("org.hsqldb.jdbc.JDBCDriver");
	         con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/desafiosefaz", "usersefaz", "123456");
	         if (con!= null){
	            System.out.println("Connection created successfully");
	            
	         }else{
	            System.out.println("Problem with creating connection");
	         }
	      
	      }  catch (Exception e) {
	         e.printStackTrace(System.out);
	      }
	   }
}
